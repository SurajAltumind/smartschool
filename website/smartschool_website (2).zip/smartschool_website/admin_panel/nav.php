
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="manage_gallery.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Gallery</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="manage_news.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">News</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="manage_event.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Events</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="manage_slider.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Slider</span>
                        </a>
                    </li>

        
                    <li class="nav-item">
                        <a class="nav-link" href="manage_alumni.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Alumni</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="share_gallery_facebook.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Share Gallery to</br> Facebook</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="contactus_details.php">
                            <i class="icon-grid menu-icon"></i>
                            <span class="menu-title">Contact Us Details</span>
                        </a>
                    </li>
                </ul>
            </nav>