<div class="contact-top">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3811.0202877083266!2d80.4182623!3d17.2178051!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a34485adc0267bb%3A0x9e066f89c3fb3b07!2sBala%20Bharathi%20Vidyalayam!5e0!3m2!1sen!2sin!4v1602844552191!5m2!1sen!2sin"></iframe>
</div>
<!--footer-->
<div class="buttom-w3">
<div class="container">
<div class="col-md-4 bottom-head text-center">
<h3><a href="index.html">KSMBBV</a></h3>
<div class="buttom-para">
<p>"Creativity is rooted in childhood. We think that every child should have the space, tools, and time to make their wildest ideas a reality. That's why we founded an art studio dedicated to the world's youngest and most fascinating creators."</p>
</div>
</div>
<div class="col-md-4 copyright text-center">
<div class="icons">
<ul>
<li><a href="https://www.facebook.com/ksmbbv"><span class="fa fa-facebook"></span></a></li>
<li><a href="#"><span class="fa fa-twitter"></span></a></li>
<li><a href="#"><span class="fa fa-rss"></span></a></li>
<li><a href="#"><span class="fa fa-vk"></span></a></li>
</ul>
</div>

</div>
<div class="col-md-4 letter-sub text-center">
<div class="sub-para">
<p><span  class="fa fa-phone" aria-hidden="true"></span>+91 8885943802</p>
<p><span  class="fa fa-envelope" aria-hidden="true"></span> admin@ksmbbv.com</p>
<p><span  class="fa fa-map-marker" aria-hidden="true"></span> THALLADA, KHAMMAM DISTRICT,</br> TELANGANA</p>
</div>
<div class="post">
<form action="#" method="post">

<div class="letter">
<input class="email" type="email" placeholder="Your email..." required="">
</div>
<div class="newsletter">
<input type="submit" value="Subscribe">
</div>
</form>
</div>
</div>
<div class="clearfix"> </div>
</div>

</div>

<footer>
<p> KSMBBV &copy; <?php echo date('Y'); ?> . All Rights Reserved   <a href="http://w3layouts.com/" target="_blank">  </a></p>
</footer>
<script type='text/javascript' src='js/jquery-2.2.3.min.js'></script>
<!-- //js -->

<script src="js/bootstrap.min.js"></script>	

<!-- FlexSlider -->
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
$(function(){

});
$(window).load(function(){
$('.flexslider').flexslider({
animation: "slide",
start: function(slider){
$('body').removeClass('loading');
}
});
});
</script>
<!-- FlexSlider -->


<!-- Portfolio -->
<script src="js/main.js"></script>
<!-- //Portfolio -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
$(".scroll").click(function(event){		
event.preventDefault();
$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
});
});
</script>
<!-- start-smoth-scrolling -->

<!-- for-bottom-to-top smooth scrolling -->
<script type="text/javascript">
$(document).ready(function() {

var defaults = {
containerID: 'toTop', // fading element id
containerHoverID: 'toTopHover', // fading element hover id
scrollSpeed: 1200,
easingType: 'linear' 
};

$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>

<!-- //for-bottom-to-top smooth scrolling -->


</body>
</html> 