<!DOCTYPE html>
<html lang="zxx">
<head>
<title>ksmbbv</title>
<!--meta tags -->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="Feature Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--//meta tags ends here-->
<!--booststrap-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" >

<!--//booststrap end-->

<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font-awesome.min.css" />

<!-- //font-awesome icons -->
<!--stylesheets-->
<link href="css/style.css" rel='stylesheet' type='text/css' media="all">
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" /> <!-- For-News-CSS -->

<link href="css/main.css" rel="stylesheet"/> <!-- For-Portfolio-CSS -->
<link href="//fonts.googleapis.com/css?family=Asap+Condensed:400,500,600,700" rel="stylesheet">
<!--//style sheet end here-->

<!-------WhatsApp Chat button Code Start----------->

<style>
/* for desktop */
.whatsapp_float {
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:100px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
        font-size:30px;
	box-shadow: 2px 2px 3px #999;
        z-index:100;
}

.whatsapp-icon {
	margin-top:16px;
}
/* for mobile */
@media screen and (max-width: 767px){
     .whatsapp-icon {
	 margin-top:10px;
     }
    .whatsapp_float {
        width: 40px;
        height: 40px;
        bottom: 20px;
        right: 10px;
        font-size: 22px;
    }
}
</style>
<!--------End WhatsApp Chat Code--------------->
</head>
<body>
<a href="https://wa.me/+91" class="whatsapp_float" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>

<div class="banner-w3">
<div class="container">
<div class="w3-agile-logo">
<div class=" head-wl">
<div class="headder-w3">
<h1><a href="index.php"><img src="images/logo.png"></a></h1>
</div>
<div class=" tele">
   
<p><font color="black"><span  class="fa fa-phone" aria-hidden="true"></span><b>  +91 8885943802</b></font></p>
<p><font color="black"><span  class="fa fa-envelope" aria-hidden="true"></span><b> admin@ksmbbv.com</b></font></p>

</div>
<div class="clearfix"> </div>
</div>
</div>
<!-- header -->
<header>

