<div class="header-w3">
<nav class="navbar navbar-expand-lg navbar-light bg-light">

<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto menu-list">
    <li class="nav-item active"><a class="nav-link" href="#">Home </a></li>
    <li><a href="#about" class=" scroll">About</a></li>
    <li><a href="#gallery" class=" scroll">Gallery</a></li>
    <li><a href="#news" class=" scroll">News</a></li>
    <li><a href="#events" class=" scroll">Events</a></li>
    <li><a href="#alumni" class=" scroll">Alumni</a></li>
    <li><a href="#contact" class=" scroll">Contact</a></li>
    </ul>
    </div>
</nav>
<div class="clearfix"> </div>
</div>
</header>